<?php 
// print_r($_FILES);
        $name = "";
        $email = "";
        $website = "";
        $number = "";
        $gender = "";
        $commands = "";

        // File upload
        $target_dir = "images/";
        $target_file = $target_dir . basename(isset($_FILES["fileupload"]["name"]));
        $uploadOk = 1;
        $filetype = isset($_FILES["fileupload"]["name"]);
        $allowed = array("jpeg", "gif", "png", "jpg", "svg", "pdf");
        

        // checking updated file image or anything else
        if(isset($_POST["submit"])) {
            $check = getimagesize($_FILES["fileupload"]["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image";
                $uploadOk = 0;
            }
        }

        // check file is alreay exist
        if(file_exists($_SERVER["DOCUMENT_ROOT"].$target_file)) {
            echo "The file is alreay selected try another image";
            $uploadOk = 0;
        }


        // check the file size 
        if(isset($_FILES["fileupload"]["size"]) > 50) {
            echo "The selected file size is to large";
            $uploadOk = 0;
        }

        // allowed file formats
        if(!in_array($filetype, $allowed) && isset($_POST["submit"])) {
            echo "The selected format is not an a image";
            $uploadOk = 0;
        }

        // check the fine uploadOk 
        if($uploadOk == 0) {
            echo "Sorry! your file was not updated";
        } else {
            if(move_uploaded_file(isset($_FILES["fileupload"]["tmp_name"]), $target_file)) {
                echo "The file" . htmlspecialchars(basename(isset($_FILES["fileupload"]["name"]))) . "has been updated..";

            } elseif(move_uploaded_file(isset($_FILES["fileupload"]["tmp_name"]), $target_file) && isset($_POST["submit"])){
                echo "Sorry! there was an error updating the file.";
            }
        }

        // error message
        $nameError = $emailError = $phoneError = $genderError = $commandsError = "";

        if($_SERVER["REQUEST_METHOD"] == "POST") {
            if(empty($_POST["name"])) {
                $nameError = "Name is Required";
            } else {
                $name = get_value($_POST["name"]);
                if(!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
                    $nameINV = "Only letters and white space allowed";
                }
            }
            
            if(empty($_POST["email"])) {
                $emailError = "Email is Required";
            } else {
                $email = get_value($_POST["email"]);
                if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $emailINV = "Invalid email addres";
                }
            }
            
            $website = get_value($_POST["website"]);
            if(!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $website)) {
                $websiteINV = "Invalid website";
            }

            if(empty($_POST["phn_number"])) {
                $phoneError = "Phone Number is Required";
            } else {
                $number = get_value($_POST["phn_number"]);
            }
            
            if(empty($_POST["gender"])) {
                $genderError = "Gender is Required";
            } else {
                $gender = get_value($_POST["gender"]);
            }
            
            if(empty($_POST["commands"])) {
                $commandsError = "Commands is Required";
            } else {
                $commands = get_value($_POST["commands"]);
            }
            
        } elseif($_SERVER["REQUEST_METHOD"] == "GET") {
            echo "";
        }
        
        function get_value($data) {
            $data = trim($data);
            $data = htmlspecialchars($data);
            $data = stripslashes($data);
            return $data;
        }

        if($_SERVER["REQUEST_METHOD"] == "POST") {
            if(empty($name) || empty($email) || empty($website) || empty($gender) || empty($commands)) {
                $overall = "Below * fileds are required";
            } else {
                echo "<p>Name:" . " " . $name . "</p>";
                echo "<p>Email:" . " " . $email . "</p>";
                echo "<p>Website:" . " " . $website . "</p>";
                echo "<p>Phone Number:" . " " . $number . "</p>";
                echo "<p>Gender:" . " " . $gender . "</p>";
                echo "<p>Commands:" . " " . $commands . "</p>";
            }
        } elseif($_SERVER["REQUEST_METHOD"] == "GET") {
            echo "";
        }
    ?>