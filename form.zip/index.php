<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Forms</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<style>
.alert.alert-danger:empty {
    display: none;
}
</style>

<?php 
    require_once("form.php");
?>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(isset($overall)){ echo "<h4>" . $overall . "</h4>"; } ?>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Enter Your Name*</label>
                        <input class="form-control" type="text" name="name" value="<?php echo $name; ?>">
                        <?php if (isset($nameError)) { echo "<div class='alert alert-danger'>" .  $nameError . "</div>"; }?>
                        <?php if(isset($nameINV)) { echo "<div class='alert alert-danger'>" . $nameINV . "</div>"; } ?>
                    </div>

                    <div class="form-group">
                        <label>Enter your mail id*</label>
                        <input class="form-control" type="text" name="email" value="<?php echo $email; ?>">
                        <?php if (isset($emailError)) { echo "<div class='alert alert-danger'>" .  $emailError . "</div>"; }?>
                        <?php if(isset($emailINV)) { echo "<div class='alert alert-danger'>" . $emailINV . "</div>"; } ?>
                    </div>

                    <div class="form-group">
                        <label>Website</label>
                        <input class="form-control" type="text" name="website" value="<?php echo $website; ?>">
                        <?php if(isset($websiteINV)) { echo "<div class='alert alert-danger'>" . $websiteINV . "</div>"; } ?>
                    </div>

                    <div class="form-group">
                        <label>Phone Number*</label>
                        <input class="form-control" type="number" name="phn_number" value="<?php echo $number; ?>">
                        <?php if (isset($phoneError)) { echo "<div class='alert alert-danger'>" .  $phoneError . "</div>"; }?>
                    </div>

                    <label>Gender*</label>
                    <?php if (isset($genderError)) { echo "<div class='alert alert-danger'>" .  $genderError . "</div>"; }?>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" <?php if(isset($gender) && $gender == "male") {echo "checked";} ?> value="male" id="male">
                        <label class="form-check-label" name="gender" for="male">
                            Male
                        </label>
                    </div>

                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" <?php if(isset($gender) && $gender == "female") {echo "checked";} ?> value="female" id="female">
                        <label class="form-check-label" name="gender" for="female">
                            Female
                        </label>
                    </div>

                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" <?php if(isset($gender) && $gender == "other") {echo "checked";} ?> value="other" id="other">
                        <label class="form-check-label" name="gender" for="other">
                            Other
                        </label>
                    </div>

                    <div class="form-group">
                        <label>Commands*</label>
                        <textarea class="form-control" name="commands"><?php echo $commands; ?></textarea>
                        <?php if (isset($commandsError)) { echo "<div class='alert alert-danger'>" .  $commandsError . "</div>"; }?>
                    </div>

                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="fileupload" id="fileupload">
                        <label class="custom-file-label" name="fileupload" for="fileupload">Choose file</label>
                    </div>


                    <div class="form-group">
                        <input class="btn btn-primary" type="submit" name="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">

            </div>
        </div>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="js/custom.js"></script>
</html>